const express = require('express');
const router = express.Router();
const BodyParser = require('body-parser');
//middlewares
const urlencodedparser = BodyParser.urlencoded({extended: false});
const jsonParser = BodyParser.json();



router.get('/',function(req,res){
	res.render('Student');
});





module.exports = router;
