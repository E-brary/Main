const express = require('express');
const router = express.Router();
const BodyParser = require('body-parser');
const mongoose = require('mongoose');
const Register = require('../Models/Register');
const passport = require('passport');
const io = require('socket.io')(http);
//middlewares
const urlencodedparser = BodyParser.urlencoded({extended: false});
const jsonParser = BodyParser.json();
mongoose.connect('mongodb://localhost:27017/Project_1',{useNewUrlParser: true});
io.on('connection',function (socket) {
	socket.on('encounter',function (data) {
		console.log(data);
	});
});
//requests
router.get('/',function(req,res){
	res.send('dashboard Page')
});




module.exports = router;
