const express = require('express');
const router = express.Router();
const passport = require('passport');
const BodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const session = require('express-session');
require('../Config/config');
//middles
router.use(cookieParser());
router.use(passport.initialize());
router.use(passport.session())
router.use(session({
	secret:'hello',
	resave: false,
	saveUninitialized: false
}));
const urlencodedparser = BodyParser.urlencoded({extended: false});
const jsonParser = BodyParser.json();
const encounter = 0;
//calls
router.get('/', function(req,res){
	res.render('Fixed');
});
router.get('/Login',function (req,res) {
	res.render('Login');
})
router.post('/Login',urlencodedparser,passport.authenticate('local',{successRedirect:'/Feed', failureRedirect: '/Login' }),function(req,res){
  
});

module.exports = router;
