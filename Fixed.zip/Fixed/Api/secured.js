const express = require('express');
const router = express.Router();
const passport = require('passport');
const BodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const session = require('express-session');
require('../Config/config');
//middles
router.use(cookieParser());
router.use(passport.initialize());
router.use(passport.session())
router.use(session({
	secret:'hello',
	resave: false,
	saveUninitialized: false
}));
const urlencodedparser = BodyParser.urlencoded({extended: false});
const jsonParser = BodyParser.json();
//calls
router.get('/', function(req,res){
	res.render('Fixed');
});
router.post('/',urlencodedparser,passport.authenticate('local',{successRedirect:'/Feed', failureRedirect: '/Register' }),function(req,res){
  
});

module.exports = router;
